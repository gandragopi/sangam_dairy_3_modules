import 'dart:convert';

import 'package:http/http.dart' as http;

class ProductApiService {
  static const String baseUrl = 'http://10.100.78.131:8081';

  // ============================================================
  // GET ALL PRODUCTS
  // ============================================================

  static Future<List<Map<String, dynamic>>> getProducts() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/products'),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to load products. Status: ${response.statusCode}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is! List) {
      throw const FormatException(
        'Invalid products response format.',
      );
    }

    return decoded
        .whereType<Map>()
        .map(
          (item) => _normalizeProduct(
        Map<String, dynamic>.from(item),
      ),
    )
        .toList();
  }

  // ============================================================
  // GET PRODUCT BY ID
  // ============================================================

  static Future<Map<String, dynamic>> getProductById(
      int id,
      ) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/products/$id'),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to load product. Status: ${response.statusCode}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is! Map) {
      throw const FormatException(
        'Invalid product response format.',
      );
    }

    return _normalizeProduct(
      Map<String, dynamic>.from(decoded),
    );
  }

  // ============================================================
  // GET PRODUCTS BY CATEGORY
  // ============================================================

  static Future<List<Map<String, dynamic>>> getProductsByCategory(
      String category,
      ) async {
    final response = await http.get(
      Uri.parse(
        '$baseUrl/api/products/category/'
            '${Uri.encodeComponent(category)}',
      ),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to load category products. '
            'Status: ${response.statusCode}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is! List) {
      throw const FormatException(
        'Invalid category products response format.',
      );
    }

    return decoded
        .whereType<Map>()
        .map(
          (item) => _normalizeProduct(
        Map<String, dynamic>.from(item),
      ),
    )
        .toList();
  }

  // ============================================================
  // NORMALIZE PRODUCT
  // ============================================================

  static Map<String, dynamic> _normalizeProduct(
      Map<String, dynamic> product,
      ) {
    final Map<String, dynamic> normalized =
    Map<String, dynamic>.from(product);

    // ------------------------------------------------------------
    // BASIC VALUES
    // ------------------------------------------------------------

    normalized['name'] =
        product['name']?.toString() ?? '';

    normalized['category'] =
        product['category']?.toString() ?? '';

    normalized['image'] =
        product['image']?.toString() ?? '';

    normalized['fat'] =
        product['fat']?.toString() ?? '';

    normalized['snf'] =
        product['snf']?.toString() ?? '';

    normalized['packSize'] =
        product['packSize']?.toString() ?? '';

    normalized['shelfLife'] =
        product['shelfLife']?.toString() ?? '';

    normalized['storage'] =
        product['storage']?.toString() ?? '';

    normalized['description'] =
        product['description']?.toString() ?? '';

    // ------------------------------------------------------------
    // PRICE
    // ------------------------------------------------------------

    final dynamic priceValue = product['price'];

    if (priceValue is num) {
      normalized['price'] = priceValue;
    } else {
      normalized['price'] =
          num.tryParse(
            priceValue?.toString() ?? '',
          ) ??
              0;
    }

    // ------------------------------------------------------------
    // VARIANTS
    // ------------------------------------------------------------

    final dynamic variantsValue = product['variants'];

    if (variantsValue is List) {
      normalized['variants'] = _normalizeVariants(
        variantsValue,
      );
    } else if (variantsValue is String &&
        variantsValue.trim().isNotEmpty) {
      try {
        final dynamic decodedVariants =
        jsonDecode(variantsValue);

        if (decodedVariants is List) {
          normalized['variants'] =
              _normalizeVariants(decodedVariants);
        } else {
          normalized['variants'] = <Map<String, dynamic>>[];
        }
      } catch (_) {
        normalized['variants'] =
        <Map<String, dynamic>>[];
      }
    } else {
      normalized['variants'] =
      <Map<String, dynamic>>[];
    }

    return normalized;
  }

  // ============================================================
  // NORMALIZE VARIANTS
  // ============================================================

  static List<Map<String, dynamic>> _normalizeVariants(
      List<dynamic> variants,
      ) {
    return variants
        .whereType<Map>()
        .map(
          (variant) {
        final Map<String, dynamic> item =
        Map<String, dynamic>.from(variant);

        return {
          ...item,
          'label':
          item['label']?.toString() ?? '',
          'packSize':
          item['packSize']?.toString() ?? '',
          'image':
          item['image']?.toString() ?? '',
          'price': item['price'] is num
              ? item['price']
              : num.tryParse(
            item['price']?.toString() ?? '',
          ) ??
              0,
        };
      },
    )
        .toList();
  }
}
