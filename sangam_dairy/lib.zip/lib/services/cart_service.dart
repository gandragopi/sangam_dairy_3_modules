import 'dart:convert';

import 'package:http/http.dart' as http;

class CartService {
  // ============================================================
  // BACKEND
  // ============================================================

  static const String baseUrl = 'http://10.100.78.131:8081';

  // Temporary cart identifier.
  // Later, when backend login/user system is added,
  // this can be replaced with the real user ID.
  static const String _cartKey = 'guest_cart';

  // ============================================================
  // GET CART
  // ============================================================

  static Future<List<Map<String, dynamic>>> getCart() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/cart/$_cartKey'),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to load cart. Status: ${response.statusCode}',
      );
    }

    final dynamic data = jsonDecode(response.body);

    if (data is! List) {
      return [];
    }

    return data.map<Map<String, dynamic>>((item) {
      final Map<String, dynamic> cartItem =
      Map<String, dynamic>.from(item as Map);

      cartItem['id'] = cartItem['id'];
      cartItem['productId'] = cartItem['productId'];
      cartItem['name'] = cartItem['productName'];
      cartItem['image'] = cartItem['image'];
      cartItem['packSize'] = cartItem['packSize'];
      cartItem['price'] = _toNum(cartItem['price']);
      cartItem['quantity'] = _toInt(cartItem['quantity']);

      return cartItem;
    }).toList();
  }

  // ============================================================
  // ADD TO CART
  // ============================================================

  static Future<void> addToCart(
      Map<String, dynamic> product, {
        int quantity = 1,
      }) async {
    final dynamic rawProductId = product['id'];

    if (rawProductId == null) {
      throw Exception(
        'Product ID is missing. Please reload the product from backend.',
      );
    }

    final int productId = rawProductId is int
        ? rawProductId
        : int.parse(rawProductId.toString());

    final String productName =
        product['name']?.toString() ?? '';

    final String image =
        product['image']?.toString() ?? '';

    final String packSize =
        product['packSize']?.toString() ?? '';

    final num price =
    _toNum(product['price']);

    final Map<String, dynamic> body = {
      'cartKey': _cartKey,
      'productId': productId,
      'productName': productName,
      'image': image,
      'packSize': packSize,
      'price': price,
      'quantity': quantity,
    };

    final response = await http.post(
      Uri.parse('$baseUrl/api/cart'),
      headers: const {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: jsonEncode(body),
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to add product to cart. '
            'Status: ${response.statusCode}',
      );
    }
  }

  // ============================================================
  // INCREASE QUANTITY
  // ============================================================

  static Future<void> increaseQuantity(String productName) async {
    final List<Map<String, dynamic>> cart = await getCart();

    final Map<String, dynamic>? item = _findItemByName(
      cart,
      productName,
    );

    if (item == null) {
      return;
    }

    final int currentQuantity =
    _toInt(item['quantity']);

    await _updateQuantity(
      item['id'],
      currentQuantity + 1,
    );
  }

  // ============================================================
  // DECREASE QUANTITY
  // ============================================================

  static Future<void> decreaseQuantity(String productName) async {
    final List<Map<String, dynamic>> cart = await getCart();

    final Map<String, dynamic>? item = _findItemByName(
      cart,
      productName,
    );

    if (item == null) {
      return;
    }

    final int currentQuantity =
    _toInt(item['quantity']);

    if (currentQuantity <= 1) {
      await removeFromCart(productName);
      return;
    }

    await _updateQuantity(
      item['id'],
      currentQuantity - 1,
    );
  }

  // ============================================================
  // UPDATE QUANTITY
  // ============================================================

  static Future<void> _updateQuantity(
      dynamic cartItemId,
      int quantity,
      ) async {
    final int id = cartItemId is int
        ? cartItemId
        : int.parse(cartItemId.toString());

    final response = await http.put(
      Uri.parse('$baseUrl/api/cart/$id'),
      headers: const {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: jsonEncode({
        'quantity': quantity,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to update cart quantity. '
            'Status: ${response.statusCode}',
      );
    }
  }

  // ============================================================
  // REMOVE FROM CART
  // ============================================================

  static Future<void> removeFromCart(String productName) async {
    final List<Map<String, dynamic>> cart = await getCart();

    final Map<String, dynamic>? item = _findItemByName(
      cart,
      productName,
    );

    if (item == null) {
      return;
    }

    final dynamic rawId = item['id'];

    if (rawId == null) {
      throw Exception('Cart item ID is missing.');
    }

    final int id = rawId is int
        ? rawId
        : int.parse(rawId.toString());

    final response = await http.delete(
      Uri.parse('$baseUrl/api/cart/$id'),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to remove cart item. '
            'Status: ${response.statusCode}',
      );
    }
  }

  // ============================================================
  // CLEAR CART
  // ============================================================

  static Future<void> clearCart() async {
    final response = await http.delete(
      Uri.parse('$baseUrl/api/cart/clear/$_cartKey'),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode != 200) {
      throw Exception(
        'Failed to clear cart. '
            'Status: ${response.statusCode}',
      );
    }
  }

  // ============================================================
  // CART ITEM COUNT
  // ============================================================

  static Future<int> getCartItemCount() async {
    final List<Map<String, dynamic>> cart = await getCart();

    int count = 0;

    for (final item in cart) {
      count += _toInt(item['quantity']);
    }

    return count;
  }

  // ============================================================
  // CART TOTAL
  // ============================================================

  static Future<double> getCartTotal() async {
    final List<Map<String, dynamic>> cart = await getCart();

    double total = 0;

    for (final item in cart) {
      final double price =
      _toNum(item['price']).toDouble();

      final int quantity =
      _toInt(item['quantity']);

      total += price * quantity;
    }

    return total;
  }

  // ============================================================
  // FIND ITEM
  // ============================================================

  static Map<String, dynamic>? _findItemByName(
      List<Map<String, dynamic>> cart,
      String productName,
      ) {
    for (final item in cart) {
      if (item['name']?.toString() == productName) {
        return item;
      }
    }

    return null;
  }

  // ============================================================
  // NUMBER HELPERS
  // ============================================================

  static num _toNum(dynamic value) {
    if (value is num) {
      return value;
    }

    return num.tryParse(value?.toString() ?? '') ?? 0;
  }

  static int _toInt(dynamic value) {
    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(value?.toString() ?? '') ?? 0;
  }
}
